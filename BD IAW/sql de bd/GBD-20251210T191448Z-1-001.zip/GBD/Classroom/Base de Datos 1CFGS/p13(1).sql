1. Crear una tabla llamada TNoaTrab que contenga todos los datos de las trabajadores
que esten en una universidad con mas de 200 plazas y con menos de 2 profesores.

CREATE TABLE TNoaTrab AS
(select * from trabajadores where



2. Añade una persona en la Universidad de Huelva con el dni “12345678”, tu nombre, el
salario y función la misma que la de “Montes García, M.Pilar”





3. Crea una tabla llamada Tsalario que muestre el nombre de la universidad donde
trabaja, dni, apellido y salario de los trabajadores que tenga un salario comprendido
entre 180000 y 210000. Los campos de la nueva tabla se han de llamar(dni, apellidos,
universidad y sueldo).






4. Suma al sueldo de los catedraticos 500





5. Cambia las personas que no son profesores y que están en la universidad de Cadiz a
la Universidad de Malaga





6. Refleja en el esquema que el profesor De Lucas Fdez, M.Angel ha dejado de ser
catedrático






7. Realiza todas las operaciones necesarias para borrar todos los profesores de la
universidad de sevilla;
