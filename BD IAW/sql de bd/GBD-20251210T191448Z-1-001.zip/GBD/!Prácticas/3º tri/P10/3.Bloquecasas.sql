INSERT 
  INTO BloqueCasas (calle, numero, metros_b, od_bloque)
  VALUES ('Cruz Conde',20,60,null);
INSERT 
  INTO BloqueCasas (calle, numero, metros_b, od_bloque)
  VALUES ('Ronda de los Tejares',15,70,null);
INSERT 
  INTO BloqueCasas (calle, numero, metros_b, od_bloque)
  VALUES ('Avenida Am�rica',20,100,null);
INSERT 
  INTO BloqueCasas (calle, numero, metros_b, od_bloque)
  VALUES ('La Paz',5,60,null);
INSERT 
  INTO BloqueCasas (calle, numero, metros_b, od_bloque)
  VALUES ('Felipe II',14,70,null);
INSERT 
  INTO BloqueCasas (calle, numero, metros_b, od_bloque)
  VALUES ('Avenida el Brillante',20,80,null);
INSERT 
  INTO BloqueCasas (calle, numero, metros_b, od_bloque)
  VALUES ('Damasco',20,80,null);