INSERT 
  INTO HabitaPiso (dni,calle,numero,escalera,planta,puerta)
  VALUES (40806020,'Ronda de los Tejares',15,'2',2,'3');
INSERT 
  INTO HabitaPiso (dni,calle,numero,escalera,planta,puerta)
  VALUES (30605020,'Damasco',20,'1',1,'3');
INSERT 
  INTO HabitaPiso (dni,calle,numero,escalera,planta,puerta)
  VALUES (80140621,'Avenida Am�rica',20,'3',4,'1');
INSERT 
  INTO HabitaPiso (dni,calle,numero,escalera,planta,puerta)
  VALUES (70200200,'Avenida Am�rica',20,'3',4,'1');
INSERT 
  INTO HabitaPiso (dni,calle,numero,escalera,planta,puerta)
  VALUES (70500150,'Avenida Am�rica',20,'3',4,'1');
INSERT 
  INTO HabitaPiso (dni,calle,numero,escalera,planta,puerta)
  VALUES (71800200,'Felipe II',14,'2',3,'1');
INSERT 
  INTO HabitaPiso (dni,calle,numero,escalera,planta,puerta)
  VALUES (44351312,'Ronda de los Tejares',15,'2',2,'3');
INSERT 
  INTO HabitaPiso (dni,calle,numero,escalera,planta,puerta)
  VALUES (32602050,'Damasco',20,'1',1,'3');
INSERT 
  INTO HabitaPiso (dni,calle,numero,escalera,planta,puerta)
  VALUES (80140620,'Avenida Am�rica',20,'3',4,'1');
INSERT 
  INTO HabitaPiso (dni,calle,numero,escalera,planta,puerta)
  VALUES (60606070,'Damasco',20,'3',2,'2');
INSERT 
  INTO HabitaPiso (dni,calle,numero,escalera,planta,puerta)
  VALUES (70800200,'Damasco',20,'2',3,'1');
INSERT 
  INTO HabitaPiso (dni,calle,numero,escalera,planta,puerta)
  VALUES (60696867,'Cruz Conde',20,'B',1,'2');
INSERT 
  INTO HabitaPiso (dni,calle,numero,escalera,planta,puerta)
  VALUES (80806059,'La Paz',5,'1',2,'5');
INSERT 
  INTO HabitaPiso (dni,calle,numero,escalera,planta,puerta)
  VALUES (59607071,'Avenida el Brillante',20,'4',1,'2');
INSERT 
  INTO HabitaPiso (dni,calle, numero, escalera, planta, puerta)
  VALUES(81140621,'Avenida Am�rica',20,'3',2,'1');
INSERT 
  INTO HabitaPiso (dni,calle, numero, escalera, planta, puerta)
  VALUES(60607071,'Avenida el Brillante',20,'4',2,'1');
INSERT 
  INTO HabitaPiso (dni,calle, numero, escalera, planta, puerta)
  VALUES(67698760,'Cruz Conde',20,'B',2,'1');
INSERT 
  INTO HabitaPiso (dni,calle, numero, escalera, planta, puerta)
  VALUES(70001000,'Felipe II',14,'2',2,'1');
INSERT 
  INTO HabitaPiso (dni,calle, numero, escalera, planta, puerta)
  VALUES(81807060,'La Paz',5,'1',1,'2');
INSERT 
  INTO HabitaPiso (dni,calle, numero, escalera, planta, puerta)
  VALUES(30306060,'Ronda de los Tejares',15,'2',3,'1');