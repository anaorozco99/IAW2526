INSERT 
  INTO Piso (calle, numero, escalera, planta, puerta, metros_p, 
       od_piso, dni_p)
  VALUES('Cruz Conde',20,'B',1,'2',60,'',60696867);
INSERT 
  INTO Piso (calle, numero, escalera, planta, puerta, metros_p, 
       od_piso, dni_p)
  VALUES('Ronda de los Tejares',15,'2',2,'3',70,'',44351312);
INSERT 
  INTO Piso (calle, numero, escalera, planta, puerta, metros_p, 
       od_piso, dni_p)
  VALUES('Avenida Am�rica',20,'3',4,'1',100,'',80140620);
INSERT 
  INTO Piso (calle, numero, escalera, planta, puerta, metros_p, 
       od_piso, dni_p)
  VALUES('La Paz',5,'1',2,'5',60,'',80806059);
INSERT 
  INTO Piso (calle, numero, escalera, planta, puerta, metros_p, 
       od_piso, dni_p)
  VALUES('Avenida el Brillante',20,'4',1,'2',80,'',59607071);
INSERT 
  INTO Piso (calle, numero, escalera, planta, puerta, metros_p, 
       od_piso, dni_p)
  VALUES('Damasco',20,'1',1,'3',40,'',32602050);
INSERT 
  INTO Piso (calle, numero, escalera, planta, puerta, metros_p, 
       od_piso, dni_p)
  VALUES('Damasco',20,'3',2,'2',70,'',60606070);
INSERT 
  INTO Piso (calle, numero, escalera, planta, puerta, metros_p, 
       od_piso, dni_p)
  VALUES('Damasco',20,'2',3,'1',50,'',70800200);
INSERT 
  INTO Piso (calle, numero, escalera, planta, puerta, metros_p, 
       od_piso, dni_p)
  VALUES('Felipe II',14,'2',3,'1',50,'',71800200);
INSERT 
  INTO Piso (calle, numero, escalera, planta, puerta, metros_p, 
       od_piso, dni_p)
  VALUES('Avenida Am�rica',20,'3',2,'1',90,'',81140621);
INSERT 
  INTO Piso (calle, numero, escalera, planta, puerta, metros_p, 
       od_piso, dni_p)
  VALUES('Avenida el Brillante',20,'4',2,'1',90,'',60607071);
INSERT 
  INTO Piso (calle, numero, escalera, planta, puerta, metros_p, 
       od_piso, dni_p)
  VALUES('Cruz Conde',20,'B',2,'1',75,'',67698760);
INSERT 
  INTO Piso (calle, numero, escalera, planta, puerta, metros_p, 
       od_piso, dni_p)
  VALUES('Felipe II',14,'2',2,'1',70,'',70001000);
INSERT 
  INTO Piso (calle, numero, escalera, planta, puerta, metros_p, 
       od_piso, dni_p)
  VALUES('La Paz',5,'1',1,'2',60,'',81807060);
INSERT 
  INTO Piso (calle, numero, escalera, planta, puerta, metros_p, 
       od_piso, dni_p)
  VALUES('Ronda de los Tejares',15,'2',3,'1',75,'',30306060);
