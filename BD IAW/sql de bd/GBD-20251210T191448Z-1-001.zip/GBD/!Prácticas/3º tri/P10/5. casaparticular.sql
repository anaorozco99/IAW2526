INSERT 
  INTO CasaParticular (calle, numero, metros_c,od_casa,dni_cp)
  VALUES('Avenida el Brillante',15,120,'Casa',15304050);
INSERT 
  INTO CasaParticular (calle, numero, metros_c,od_casa,dni_cp)
  VALUES('Urbanizaci�n las Lomas',53,200,'Chalet',10154060);
INSERT 
  INTO CasaParticular (calle, numero, metros_c,od_casa,dni_cp)
  VALUES('El Palo',15,50,'',15060615);
INSERT 
  INTO CasaParticular (calle, numero, metros_c,od_casa,dni_cp)
  VALUES('Los Pinos',5,230,'',30201505);
INSERT 
  INTO CasaParticular (calle, numero, metros_c,od_casa,dni_cp)
  VALUES('Saravia',3,100,'',70100506);
INSERT 
  INTO CasaParticular (calle, numero, metros_c,od_casa,dni_cp)
  VALUES('Damasco',23,120,'',70100501);
INSERT 
  INTO CasaParticular (calle, numero, metros_c,od_casa,dni_cp)
  VALUES('Damasco',24,90,'',70100502);
INSERT 
  INTO CasaParticular (calle, numero, metros_c,od_casa,dni_cp)
  VALUES('Guerra',2,150,'',71100501);