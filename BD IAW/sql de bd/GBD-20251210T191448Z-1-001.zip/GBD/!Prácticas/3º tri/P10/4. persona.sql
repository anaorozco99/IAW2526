INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona, 
       dni_c, calle,numero)
  VALUES (44351312,'Juan','P�rez L�pez','H',44351312,
         'Ronda de los Tejares',15);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (40806020,'Mar�a','Garc�a Gonz�lez','M',44351312,
         'Ronda de los Tejares',15);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (30605020,'Josefa','Garc�a P�rez','M',30605020,
         'Damasco',20);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (32602050,'Antonio','Fern�ndez Fern�ndez','H',30605020,
         'Damasco',20);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (80140620,'Antonio','Garc�a Garc�a','H',80140620,
         'Avenida Am�rica',20);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (80140621,'Antonia','P�rez L�pez','M',80140620,
         'Avenida Am�rica',20);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (70200200,'Antonio','Garc�a P�rez','H',80140620,
         'Avenida Am�rica',20);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (70500150,'Mar�a','Garc�a P�rez','H',80140620,
         'Avenida Am�rica',20);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (30700200,'Jos�','L�pez Garc�a','H',30700200,
         'Saravia',3);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (60606070,'Pedro','Jim�nez Cruz','H',60606070,
         'Damasco',20);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (70800200,'Teresa','Guti�rrez P�rez','M',70800200,
         'Damasco',20);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (60696867,'Petra','Zafra Polo','M',60696867,
         'Cruz Conde',20);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (80806059,'Mar�a','Gonz�lez Mu�oz','M',80806059,
         'La Paz',5);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (59607071,'Rafael','L�pez L�pez','M',59607071,
         'Avenida el Brillante',20);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (70100506,'Mar�a Luisa','La Torre Espinosa','M',70100506,
         'Saravia',3);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (60302930,'Enrique','P�rez S�nchez','H',70100506,
         'Saravia',3);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (15304050,'Gonzalo','L�pez Jim�nez','H',15304050,
         'Avenida el Brillante',15);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (10203040,'Dolores','Cerruela P�rez','m',15304050,
         'Avenida el Brillante',15);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (20503080,'Jos�','L�pez P�rez','H',15304050,
         'Avenida el Brillante',15);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (10154060,'Teresa','Garrido Ortiz','M',10154060,
         'Urbanizaci�n las Lomas',53);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (30201505,'Juan','Garc�a Exp�sito','H',30201505,
         'Los Pinos',5);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (15060615,'Federico','Mart�n Garc�a','H',15060615,
         'El Palo',15);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (71800200,'Gonzalo','Garc�a Garc�a','H',71800200,
         'Felipe II',14);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (70100501,'jos�','L�pez Garc�a','H',70100501,
         'Damasco',23);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (70100502,'Gustavo','Cerruela Garc�a','H',70100502,
         'Damasco',24);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (71100501,'Pedro','Garc�a Jim�nez','H',71100501,
         'Guerra',2);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (81140621,'Jos�','P�rez L�pez','H',81140621,
         'Avenida Am�rica',20);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (60607071,'Gonzalo','P�rez Polo','H',60607071,
         'Avenida el Brillante',20);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (67698760,'Maria','Polo Mu�oz','M',67698760,
         'Cruz Conde',20);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (70001000,'Luis','Garrido L�pez','H',70001000,
         'Felipe II',14);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (81807060,'Jos�','Munoz Grrido','H',81807060,'La Paz',5);
INSERT 
  INTO Persona (dni,nombre_persona,apellidos_persona,od_persona,
       dni_c,calle,numero)
  VALUES (30306060,'Gonzalo','Castillo Garc�a','H',30306060,
         'Ronda de los Tejares',15);