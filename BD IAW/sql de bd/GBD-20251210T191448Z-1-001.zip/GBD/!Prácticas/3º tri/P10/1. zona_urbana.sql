INSERT 
  INTO ZonaUrbana (nombre_zona,od_zona) 
  VALUES ('CENTRO','Es la zona correspondiente al centro de la 
         ciudad');
INSERT 
  INTO ZonaUrbana (nombre_zona,od_zona) 
  VALUES ('SECTOR SUR','Es la zona correspondiente al sur de la 
         ciudad');
INSERT 
  INTO ZonaUrbana (nombre_zona,od_zona) 
  VALUES ('SUBURBIO TERMINAL','Es la zona correspondiente a la 
         zona pobre de la ciudad');
INSERT 
  INTO ZonaUrbana (nombre_zona,od_zona) 
  VALUES ('BRILLANTE','Es la zona correspondiente mas alta de la 
         ciudad');
INSERT 
  INTO ZonaUrbana (nombre_zona,od_zona) 
  VALUES ('TRASIERRA','Es la zona correspondiente a la zona 
         cercana a la sierra de la ciudad');
