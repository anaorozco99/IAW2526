insert into puerto values ('Alto del Naranco',565,'1',6.90,10,30);
insert into puerto values ('Arcalis',2230,'E',6.50,10,4);
insert into puerto values ('Cerler-Circo de Ampriu',2500,'E',5.87,11,9);
insert into puerto values ('Coll de la Comella',1362,'1',8.07,10,2);
insert into puerto values ('Coll de Ordino',1980,'E',5.30,10,7);
insert into puerto values ('Cruz de la Demanda',1850,'E',7.00,11,20);
insert into puerto values ('Lagos de Covadonga',1134,'E',6.86,16,42);
insert into puerto values ('Navacerrada',1860,'1',7.50,19,2);
insert into puerto values ('Puerto de Alisas',672,'1',5.80,15,1);
insert into puerto values ('Puerto de la Morcuera',1760,'2',6.50,19,2);
insert into puerto values ('Puerto de Mijares',1525,'1',4.90,18,24);
insert into puerto values ('Puerto de Navalmoral',1521,'2',4.30,18,2);
insert into puerto values ('Puerto de Pedro Bernardo',1250,'1',4.20,18,25);
insert into puerto values ('Sierra Nevada',2500,'E',6.00,2,26);


