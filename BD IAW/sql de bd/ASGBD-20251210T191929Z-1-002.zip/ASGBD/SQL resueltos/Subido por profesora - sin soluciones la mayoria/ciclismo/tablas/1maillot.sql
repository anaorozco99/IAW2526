Insert into  maillot values('MGE','General','Amarillo',8000000);
Insert into  maillot values('MMO','Montaña','Blanco y Rojo',2000000);
Insert into  maillot values('MMS','Mas Sufrido','Estrellitas moradas',2000000);
Insert into  maillot values('MMV','Metas volantes','Rojo',2000000);
Insert into  maillot values('MRE','Regularidad','Verde',2000000);
Insert into  maillot values('MSE','Sprints especiales','Rosa',2000000);





