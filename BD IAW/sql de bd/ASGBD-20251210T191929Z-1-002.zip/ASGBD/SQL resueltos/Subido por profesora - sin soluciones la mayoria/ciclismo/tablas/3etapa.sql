insert into etapa values (1,9,'Valladolid','Valladolid',1);
insert into etapa values (2,180,'Valladolid','Salamanca',36);
insert into etapa values (3,240,'Salamanca','Caceres',12);
insert into etapa values (4,230,'Almendralejo','Córdoba',83);
insert into etapa values (5,170,'Córdoba','Granada',27);
insert into etapa values (6,150,'Granada','Sierra Nevada',52);
insert into etapa values (7,250,'Baza','Alicante',22);
insert into etapa values (8,40,'Benidorm','Benidorm',1);
insert into etapa values (9,150,'Benidorm','Valencia',35);
insert into etapa values (10,200,'Igualada','Andorra',2);
insert into etapa values (11,195,'Andorra','Estación de Cerler',65);
insert into etapa values (12,220,'Benasque','Zaragoza',12);
insert into etapa values (13,200,'Zaragoza','Pamplona',93);
insert into etapa values (14,172,'Pamplona','Alto de la Cruz de la Demanda',86);
insert into etapa values (15,207,'Santo Domingo de la Calzada','Santander',10);
insert into etapa values (16,160,'Santander','Lagos de Covadonga',5);
insert into etapa values (17,140,'Cangas de Onis','Alto del Naranco',4);
insert into etapa values (18,195,'Ávila','Ávila',8);
insert into etapa values (19,190,'Ávila','Destilerias Dyc',2);
insert into etapa values (20,52,'Segovia','Destilerias Dyc',2);
insert into etapa values (21,170,'Destilerias Dyc','Madrid',27);





